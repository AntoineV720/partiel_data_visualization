const decreaseBtn = document.getElementById('decreaseBtn');
const increaseBtn = document.getElementById('increaseBtn');
const resetBtn = document.getElementById('resetBtn');
const countElement = document.getElementById('count');

let count = 0;

function updateCount() {
  countElement.textContent = count;
}

function decrease() {
  count--;
  updateCount();
}

function increase() {
  count++;
  updateCount();
}

function reset() {
  count = 0;
  updateCount();
}

decreaseBtn.addEventListener('click', decrease);
increaseBtn.addEventListener('click', increase);
resetBtn.addEventListener('click', reset);

