fetch('data.json')
    .then((response) => response.json())
    .then((data) => run_visualization(data));

function run_visualization(data) {
    // Tri des données par population de manière décroissante
    sortByCountryPopulation(data);

    // Sélection des 30 pays ayant la plus grande population
    const top30pays = data.slice(0, 30);

    // Création des tableaux pour les axes X et Y du graphique
    const pays = top30pays.map((item) => item.country);
    const population = top30pays.map((item) => item.population);

    // Création du graphique
    const trace = {
        x: pays.reverse(),
        y: population.reverse(),
        type: 'bar'
    };

    const layout = {
        title: 'Top 30 des pays les plus peuplés',
        xaxis: { title: 'Pays' },
        yaxis: { title: 'Population' }
    };

    Plotly.newPlot('data-viz', [trace], layout);
}

function sortByCountryPopulation(data) {
    data.sort((a, b) => b.population - a.population);
}



