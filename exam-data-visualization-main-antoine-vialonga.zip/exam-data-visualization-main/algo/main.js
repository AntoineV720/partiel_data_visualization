function twoSum(array, target) {
    const map = new Map();
  
    for (let i = 0; i < array.length; i++) {
      const complement = target - array[i];
      
      if (map.has(complement)) {
        return [map.get(complement), i];
      }
      
      map.set(array[i], i);
    }
    
    return [];
  }
  
  const nums1 = [2, 3, 4, 25];
  const target1 = 29;
  const result1 = twoSum(nums1, target1);
  console.log(result1); // Output: [0, 1]
  
    
    